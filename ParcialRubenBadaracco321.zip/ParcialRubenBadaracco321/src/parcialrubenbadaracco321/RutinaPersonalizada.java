
package parcialrubenbadaracco321;

public class RutinaPersonalizada extends Actividad implements Programable, Informable {
    private int duracionEstimada;
    

    public int getDuracionEstimada() {
        return duracionEstimada;
    }

    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad nivel, int duracionEstimada) {
        super(nombre, entrenador, nivel);
        this.duracionEstimada = duracionEstimada;
    }

    @Override
    public String programar() {
        return "Se programo la rutina personalizada: " + getNombre(); 
    }

    @Override
    public String generarInforme() {
        return "Informe de rutina personalizada: " + "Plan " +getNombre() + " ,Duracion estimada: " + duracionEstimada + "semanas";
        
    }
    
   

   @Override
    public String toString(){
        return super.toString() + " ,duracion estimada: " + duracionEstimada;
    }

   
    
    
    
}
