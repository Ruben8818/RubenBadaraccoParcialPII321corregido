
package parcialrubenbadaracco321;

import java.util.ArrayList;
import java.util.Objects;


public class ParcialRubenBadaracco321 {

   
    public static void main(String[] args) {
     
         CentroEntrenamiento centro = new CentroEntrenamiento("Alto Rendimiento Sur"); 
        
         try {
            centro.agregarActividad(
                 new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25 )
            ); 
            centro.agregarActividad(
                 new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz", NivelIntensidad.MEDIA, 8)
            );
            centro.agregarActividad( 
                  new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez", NivelIntensidad.BAJA, 78)
            );
            centro.agregarActividad(
                    new RutinaPersonalizada("Plan Resistencia", "Laura Gomez", NivelIntensidad.ALTA, 6)
            );        
             centro.agregarActividad(
                     new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20)
            );
            } catch (ActividadDuplicadaException e) {             
                  System.out.println("No se pudo agregar la actividad: " + e.getMessage());        
            } 
                  
    
         
         
         
         System.out.println("Actividades registradas:");         
         mostrarActividades(centro.obtenerActividades());          
         System.out.println();          
         System.out.println("Actividades programables:");         
         programarActividades(centro.obtenerActividades());          
         System.out.println();          
         System.out.println("Informes generados:");         
         generarInformeDesdeMain(centro.obtenerActividades());          
         System.out.println();          
         System.out.println("Actividades de intensidad ALTA:");         
         mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA)); 
         
         
    
    }
    private static void generarInformeDesdeMain(ArrayList<Actividad> actividades){
         for(Actividad a : actividades){
             Objects.requireNonNull(a);
              if(a instanceof Informable informable){
                  System.out.println(informable.generarInforme());
              }else{
                  System.out.println("La actividad: " + a.getNombre() + "no puede generar informe");
              }
         } 
    }
    
     private static void programarActividades(ArrayList<Actividad> actividades ){
         for(Actividad a : actividades){
             Objects.requireNonNull(a);
              if(a instanceof Programable programable){
                  System.out.println(programable.programar());
              }else{
                  System.out.println("La actividad: " + a.getNombre() + "no puede ser programada");
              }
         }    
        
    }
      private static void mostrarActividades(ArrayList<Actividad> actividades){
        if(actividades.isEmpty()){
            System.out.println("No hay actividades para mostrar");
        }else{
            for(Actividad a : actividades){
                System.out.println(a);
            }
        }
        
    }
    
      
     
    
   
    
}
