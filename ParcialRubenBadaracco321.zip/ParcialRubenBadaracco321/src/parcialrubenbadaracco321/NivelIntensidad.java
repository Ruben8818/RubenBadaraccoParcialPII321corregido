
package parcialrubenbadaracco321;


public enum NivelIntensidad {
    BAJA,
    MEDIA,
    ALTA;
    
}
