
package parcialrubenbadaracco321;


import java.util.Objects;
 


public abstract class Actividad {
    private String nombre;
    private String entrenador;
    private NivelIntensidad nivel;
    
    public Actividad(String nombre, String entrenador, NivelIntensidad nivel) {
        validarNombre(nombre);
        validarEntrenador(entrenador);
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.nivel = nivel;
    }
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("Nombre Invalido"); 
        }
    }
    private void validarEntrenador(String entrenador){
        if(entrenador == null || entrenador.isBlank()){
            throw new IllegalArgumentException("Entreandor invalido");
        }
    }
   
    
    @Override
    public String toString(){
        String[] x = getClass().getName().split("\\.");
        String clase = x[x.length - 1];
        return clase + "{" + " nombre: " + nombre + " ,entrenador: " + entrenador + " ,nivelIntensidad" + nivel ;
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(!(o instanceof Actividad a)){
            return false;
        }
        return nombre.equals(a.nombre) &&
                entrenador.equals(a.entrenador);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, entrenador);
    }

    public String getNombre() {
        return nombre;
    }

    public String getEntrenador() {
        return entrenador;
    }

    public NivelIntensidad getNivel() {
        return nivel;
    }
    
    
          
    
}
