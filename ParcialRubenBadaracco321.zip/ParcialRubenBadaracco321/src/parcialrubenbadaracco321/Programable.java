
package parcialrubenbadaracco321;


public interface Programable {
    String programar();
}
