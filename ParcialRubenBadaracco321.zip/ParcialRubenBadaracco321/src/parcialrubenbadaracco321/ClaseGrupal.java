
package parcialrubenbadaracco321;


public class ClaseGrupal extends Actividad implements Programable {
    private final int cantidadMaximaAlumnos;
    

    public ClaseGrupal( String nombre, String entrenador, NivelIntensidad nivel,int cantidadMaximaAlumnos) {
        super(nombre, entrenador, nivel);
        validarCantidadMaxima(cantidadMaximaAlumnos);
        this.cantidadMaximaAlumnos = cantidadMaximaAlumnos;
    }
    
    private void validarCantidadMaxima(int cantidad){
        if(cantidad <= 0 ){
            throw new IllegalArgumentException("Cantidad de pariticipantes invalida");
        }
        
    }
    public int getCantidadMaximaAlumnos() {
        return cantidadMaximaAlumnos;
    }

    @Override
    public String programar() {
        return "Se programo la clase grupal: " + getNombre();
    }
   
    
    @Override
    public String toString(){
        return super.toString() + " ,cantidad maxima alumnos: " + cantidadMaximaAlumnos;
    }

   
    
}
