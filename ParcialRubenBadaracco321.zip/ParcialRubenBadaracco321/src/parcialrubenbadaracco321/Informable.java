
package parcialrubenbadaracco321;


public interface Informable {
    String generarInforme();
    
}
