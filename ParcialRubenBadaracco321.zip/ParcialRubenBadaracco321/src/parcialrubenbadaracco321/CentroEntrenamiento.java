
package parcialrubenbadaracco321;

import java.util.ArrayList;


public class CentroEntrenamiento {
    private String nombre;
    private ArrayList<Actividad> actividades;

    public CentroEntrenamiento(String nombre) {
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }
    
    public void agregarActividad(Actividad actividad)throws ActividadDuplicadaException{
        validarActividad(actividad);
        actividades.add(actividad);
        
    }
    
    private void validarActividad(Actividad actividad)throws ActividadDuplicadaException{
        if(actividad == null || actividades.contains(actividad)){
            throw new ActividadDuplicadaException("actividad nula o acitividad: " + actividad.getNombre() + " ya esta registrada con profesor; " + actividad.getEntrenador() );
        }
    }
    
  
    
    public ArrayList<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);
    }
    
   
    
    
    
    public ArrayList<Actividad> filtrarPorNivel(NivelIntensidad nivel){
        ArrayList<Actividad> listaPorTipo = new ArrayList<>();
        for(Actividad a : actividades){
            if(a.getNivel() == nivel){
                listaPorTipo.add(a);
            }
        }
        return listaPorTipo;
        
    }
    
}
