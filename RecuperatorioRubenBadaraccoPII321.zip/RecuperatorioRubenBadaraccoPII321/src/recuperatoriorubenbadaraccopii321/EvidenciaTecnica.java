
package recuperatoriorubenbadaraccopii321;


public abstract class EvidenciaTecnica extends ArchivoExtraterrestre implements Analizable{
    
   private String fechaDeObtencion;
   private static final int MAX_CONFIABILIDAD = 100;
   private static final int MIN_CONFIABILIDAD = 0;
   private final int confiabilidad;

    public EvidenciaTecnica(String codigo, String agenciaResponsable, NivelClasificacion nivel,String fechaDeObtencion, int confiabilidad) {
        super(codigo, agenciaResponsable, nivel);
        validarFechaObtencion(fechaDeObtencion);
        validarConfiabilidad(confiabilidad);
        this.fechaDeObtencion = fechaDeObtencion;
        this.confiabilidad = confiabilidad;
    }
   
    private void validarFechaObtencion(String fechaDeObtencion){
        if(fechaDeObtencion == null || fechaDeObtencion.isBlank()){
            throw new IllegalArgumentException("Fecha invalida o nula");
        }
    }
    private void validarConfiabilidad(int confiabilidad){
        if(confiabilidad < MIN_CONFIABILIDAD || confiabilidad > MAX_CONFIABILIDAD){
            throw new IllegalArgumentException("Valor no entra entre los valores de confiabilidad aceptados");
        }
    }

    public String getFechaDeObtencion() {
        return fechaDeObtencion;
    }

    public int getConfiabilidad() {
        return confiabilidad;
    }
    
     @Override
    public String toString(){
        return super.toString() + " ,fecha de obtencion= " + getFechaDeObtencion() + ", con una confiabilidad de= " + getConfiabilidad();
    }
   
    
}
