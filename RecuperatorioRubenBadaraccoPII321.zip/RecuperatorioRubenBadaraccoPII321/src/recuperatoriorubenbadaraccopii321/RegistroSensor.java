
package recuperatoriorubenbadaraccopii321;


public class RegistroSensor extends EvidenciaTecnica  implements Informable{
    
    private final double frecuenciaDetectada;

    public RegistroSensor( String codigo, String agenciaResponsable, NivelClasificacion nivel, String fechaDeObtencion, int confiabilidad, double frecuenciaDetectada) {
        super(codigo, agenciaResponsable, nivel, fechaDeObtencion, confiabilidad);
        this.frecuenciaDetectada = frecuenciaDetectada;
    }

    

    public double getFrecuenciaDetectada() {
        return frecuenciaDetectada;
    }
    
    @Override 
    public String generarInforme(){
       return "Informe tecnico del registro: " + getCodigo() + " frecuencia detectada  " + getFrecuenciaDetectada()+"hz";
    }
    @Override
    public String analizar(){
        return "Se analizo la evidencia: " + getCodigo()  + " con un nivel de confiabilidad de " + getNivel();
    }
     @Override
    public String toString(){
        return super.toString() + " frecuencia= " + getFrecuenciaDetectada();
    }
}
