
package recuperatoriorubenbadaraccopii321;


public interface Informable {
    String generarInforme();
}
