
package recuperatoriorubenbadaraccopii321;


public enum NivelClasificacion {
     PUBLICO,
     RESERVADO,
     ULTRASECRETO;
    
}
