
package recuperatoriorubenbadaraccopii321;


public class InformeAvistamiento extends EvidenciaTecnica {
    
    private String ubicacionDeFenomeno;

    public InformeAvistamiento(String codigo, String agenciaResponsable, NivelClasificacion nivel, String fechaDeObtencion, int confiabilidad,String ubicacionDeFenomeno) {
        super(codigo, agenciaResponsable, nivel, fechaDeObtencion, confiabilidad);
        validarUbicacion(ubicacionDeFenomeno);
        this.ubicacionDeFenomeno = ubicacionDeFenomeno;
    }

    public String getUbicacionDeFenomeno() {
        return ubicacionDeFenomeno;
    }
    private void validarUbicacion(String ubicacion){
        if(ubicacion == null || ubicacion.isBlank()){
            throw new IllegalArgumentException("Ubicacion invalida");
        }
    }
    
    @Override 
    public String analizar(){
        return "Se analizo la evidencia: " + getCodigo()  + " con un nivel de confiabilidad de " + getNivel();
    }
    
    @Override
    public String toString(){
        return super.toString() + " ,Ubicacion= " + getUbicacionDeFenomeno();
    }
    
    
}
