
package recuperatoriorubenbadaraccopii321;


public class TestimoniosClasificado extends ArchivoExtraterrestre implements Informable{
    private final String aliasUtilizado;

    public TestimoniosClasificado(String aliasUtilizado, String codigo, String agenciaResponsable, NivelClasificacion nivel) {
        super(codigo, agenciaResponsable, nivel);
        validarAlias(aliasUtilizado);
        this.aliasUtilizado = aliasUtilizado;
    }

    

    public String getAliasUtilizado() {
        return aliasUtilizado;
    }
    private void validarAlias(String alias){
        if(alias == null || alias.isBlank()){
            throw new IllegalArgumentException("Alias invalido");
        }
    }
    
    @Override
    public String generarInforme(){
        return "Informe tecnico del registro: " + getCodigo() + " testigo identificado mediante el alias  " + getAliasUtilizado();
    }
    
   
    @Override
    public String toString(){
        return super.toString() + " ,alias utilizado  " + getAliasUtilizado();
    }
}
