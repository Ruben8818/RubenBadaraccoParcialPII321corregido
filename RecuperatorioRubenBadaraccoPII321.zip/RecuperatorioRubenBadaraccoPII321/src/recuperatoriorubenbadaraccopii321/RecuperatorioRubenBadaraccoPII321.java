
package recuperatoriorubenbadaraccopii321;

public class RecuperatorioRubenBadaraccoPII321 {

    
   public static void main(String[] args) {
    ArchivoDesclasificado archivo = new ArchivoDesclasificado("ProyectoDisclosure");

    try {
            archivo.agregarArchivo(new InformeAvistamiento("UAP-101", "AARO",
            NivelClasificacion.ULTRASECRETO, "14/07/2024", 92, "Desierto de Nevada"));
            archivo.agregarArchivo(new RegistroSensor("SEN-205", "Fuerza Aerea",
                    NivelClasificacion.RESERVADO, "03/09/2023", 78, 1420.5));
            archivo.agregarArchivo(new TestimoniosClasificado("TES-308", "CIA",
                       NivelClasificacion.PUBLICO, "Testigo Orion"));
            archivo.agregarArchivo(new RegistroSensor("SEN-410", "AARO",
                    NivelClasificacion.ULTRASECRETO, "21/02/2025", 96, 3150.8)); 
            archivo.agregarArchivo( new InformeAvistamiento("UAP-101", "AARO",
                    NivelClasificacion.RESERVADO, "10/10/2025", 65, "Roswell"));

    } catch (ArchivoDuplicadoException e) {
 System.out.println("No se pudo agregar el archivo: " + e.getMessage());
}
