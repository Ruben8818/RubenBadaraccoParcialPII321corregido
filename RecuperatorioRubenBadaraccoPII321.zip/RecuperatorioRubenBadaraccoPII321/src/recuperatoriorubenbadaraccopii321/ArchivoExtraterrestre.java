
package recuperatoriorubenbadaraccopii321;

import java.util.Objects;

public abstract class ArchivoExtraterrestre {
    private final String codigo;
    private final String agenciaResponsable;
    private final NivelClasificacion nivel;

    public ArchivoExtraterrestre(String codigo, String agenciaResponsable, NivelClasificacion nivel) {
        validarCodigo(codigo);
        validarAgenciaResponsable(agenciaResponsable);
        validarNivel(nivel);
        this.codigo = codigo;
        this.agenciaResponsable = agenciaResponsable;
        this.nivel = nivel;
    }
    
    
    private void validarCodigo(String codigo){
        if(codigo == null || codigo.isBlank()){
            throw new IllegalArgumentException("Codigo invalido o nulo");
        }
    }
    private void validarAgenciaResponsable(String agencia){
        if(agencia == null || agencia.isBlank()){
            throw new IllegalArgumentException("Agencia invalida o nulo");
        }
    }
    private void validarNivel(NivelClasificacion nivel){
        if(nivel == null ){
            throw new IllegalArgumentException("Nivel invalido o nulo");
        }
    }
    @Override
    public boolean equals(Object o){
        if(o == null){
            return true;
        }
        if(!(o instanceof ArchivoExtraterrestre a)){
            return false;
        }
        return codigo.equals(a.codigo) &&
                agenciaResponsable.equals(a.agenciaResponsable);
    }
    @Override
    public int hashCode(){
        return Objects.hash(codigo, agenciaResponsable);
        
    }
    
     @Override
    public String toString(){
        String[] x = getClass().getName().split("\\.");
        String clase = x[x.length - 1];
        return clase + "{" + " codigo:  " + codigo + " ,Agencia responsable:  " + agenciaResponsable + " ,nivel Clasificacion: " + nivel ;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getAgenciaResponsable() {
        return agenciaResponsable;
    }

    public NivelClasificacion getNivel() {
        return nivel;
    }
    
    
}
