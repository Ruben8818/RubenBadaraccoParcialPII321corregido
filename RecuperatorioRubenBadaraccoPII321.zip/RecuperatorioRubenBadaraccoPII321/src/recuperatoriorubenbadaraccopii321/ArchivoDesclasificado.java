
package recuperatoriorubenbadaraccopii321;

import java.util.ArrayList;
import java.util.List;


public class ArchivoDesclasificado {
    private final String nombre;
    private ArrayList<ArchivoExtraterrestre> archivos;

    public ArchivoDesclasificado(String nombre) {
        this.nombre = nombre;
        this.archivos = new ArrayList<>();
    }
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("Nombnre invalido");
        }
    }
   
    public void agregarArchivo(ArchivoExtraterrestre archivo) throws ArchivoDuplicadoException{
        validarArchivo(archivo);
        validarArchivoRepetido(archivo);
        archivos.add(archivo);
    }
    
    private void validarArchivo(ArchivoExtraterrestre archivo){
        if(archivo == null){
            throw new IllegalArgumentException("Archivo invalido no puede ser nulo");
        }
    }
    private void validarArchivoRepetido(ArchivoExtraterrestre archivo) throws ArchivoDuplicadoException{
        if(archivos.contains(archivo)){
            throw new ArchivoDuplicadoException();
        }
    }

    public String getNombre() {
        return nombre;
    }
    private void validarNivel(NivelClasificacion nivel){
        if(nivel == null){
            throw new IllegalArgumentException("nivel invalido");
        }
    }
    public ArrayList<ArchivoExtraterrestre> filtrarPorClasificacion(NivelClasificacion nivel){
        ArrayList<ArchivoExtraterrestre> filtradas = new ArrayList<>();
        for(ArchivoExtraterrestre a : archivos){
            if(a.getNivel() == nivel){
                filtradas.add(a);
            }
        }
        return filtradas;
    }
    public ArrayList<ArchivoExtraterrestre> obtenerArchivos(){
        return new ArrayList<ArchivoExtraterrestre>(archivos);
    }

    @Override
    public String toString() {
        return "ArchivoDesclasificado{" + "nombre=" + nombre + '}';
    }
    
}   
