
package recuperatoriorubenbadaraccopii321;


public interface Analizable {
    String analizar();
}
