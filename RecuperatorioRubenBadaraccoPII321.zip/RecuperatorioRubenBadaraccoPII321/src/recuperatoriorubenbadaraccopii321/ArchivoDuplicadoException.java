
package recuperatoriorubenbadaraccopii321;


public class ArchivoDuplicadoException extends Exception {
    private static final String MESSAGE = "Archivo ya se encuentra duplicado en la lista de archivos";
    
    public ArchivoDuplicadoException(){
        super(MESSAGE);
    }
    
    public ArchivoDuplicadoException(String mensaje){
        super(mensaje);
    }
}
